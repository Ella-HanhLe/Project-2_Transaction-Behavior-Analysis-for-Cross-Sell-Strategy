3. Insights 3: Promote credit cards to eligible customers based on their behavior.
    
    WITH txn_summary AS (
    SELECT
    a.customer_id,
    a.name,
    a.age,
    COUNT(c.transaction_id) AS txn_count,
    AVG(c.amount) AS avg_amount
    FROM customers a
    JOIN accounts b ON a.customer_id = b.customer_id
    JOIN transactions c ON b.account_id = c.account_id
    GROUP BY a.customer_id, a.name, a.age
    ),
    avg_metrics AS (
    SELECT
    AVG(txn_count) AS avg_txn,
    AVG(avg_amount) AS avg_amt
    FROM txn_summary
    )
    SELECT s.*
    FROM txn_summary s
    JOIN avg_metrics m
    ON s.txn_count > m.avg_txn AND s.avg_amount > m.avg_amt
    WHERE s.age BETWEEN 25 AND 44