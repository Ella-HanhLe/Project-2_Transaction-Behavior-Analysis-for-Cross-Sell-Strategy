1. Insights 1: Fund transfer usage by segment.
    
    SELECT 
    
       CAST(FLOOR(a.age / 10) * 10 AS INTEGER) AS age_group,
    
       a.gender,
    
       COUNT(c.transaction_id) AS Fund_Transfer_count
    
    FROM customers a
    
    JOIN accounts b ON a.customer_id = b.customer_id
    
    JOIN transactions c ON b.account_id = c.account_id
    
    WHERE c.type = ‘Fund Transfer’
    
    GROUP BY  CAST(FLOOR(a.age / 10) * 10 AS INTEGER),
    
              a.gender
    
    *ORDER BY Fund_Transfer_count DESC;