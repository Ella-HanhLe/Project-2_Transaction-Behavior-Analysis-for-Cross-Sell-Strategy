2. Inssights 2: Average monthly speding by region and age group
    
    SELECT
        a.region,
        FLOOR(a.age / 10) * 10 AS age_group,
        EXTRACT(MONTH FROM c.transaction_date) AS month,
        AVG(c.amount) AS average_amount
    FROM customers a
    JOIN accounts b ON a.customer_id = b.customer_id
    JOIN transactions c ON b.account_id = c.account_id
    WHERE c.type IN ('Bill Payment', 'Fund Transfer')
    GROUP BY  a.region,
                      FLOOR(a.age / 10) * 10,
                     EXTRACT(MONTH FROM c.transaction_date);